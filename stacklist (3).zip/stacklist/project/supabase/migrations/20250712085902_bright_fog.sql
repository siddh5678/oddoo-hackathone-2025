/*
  # Fix Foreign Key Relationships

  1. Database Changes
    - Add missing foreign key constraint between questions and profiles tables
    - Ensure proper relationships for Supabase PostgREST to work correctly
  
  2. Security
    - Maintain existing RLS policies
*/

-- Add the missing foreign key constraint between questions and profiles
ALTER TABLE questions 
ADD CONSTRAINT fk_questions_author 
FOREIGN KEY (author_id) REFERENCES profiles(id) ON DELETE CASCADE;

-- Add foreign key constraint between answers and profiles  
ALTER TABLE answers 
ADD CONSTRAINT fk_answers_author 
FOREIGN KEY (author_id) REFERENCES profiles(id) ON DELETE CASCADE;

-- Ensure the accepted_answer foreign key exists
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'fk_accepted_answer'
  ) THEN
    ALTER TABLE questions 
    ADD CONSTRAINT fk_accepted_answer 
    FOREIGN KEY (accepted_answer_id) REFERENCES answers(id) ON DELETE SET NULL;
  END IF;
END $$;