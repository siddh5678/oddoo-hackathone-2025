/*
  # Create StackIt Database Schema

  1. New Tables
    - `profiles` - User profiles extending Supabase auth
    - `questions` - Questions posted by users
    - `answers` - Answers to questions
    - `tags` - Available tags for categorizing questions
    - `question_tags` - Many-to-many relationship between questions and tags
    - `votes` - User votes on answers
    - `notifications` - User notifications

  2. Security
    - Enable RLS on all tables
    - Add policies for proper access control
    - Users can only modify their own content
    - Public read access for questions and answers

  3. Features
    - Automatic score calculation for answers based on votes
    - User reputation tracking
    - Default tags for common topics
*/

-- Create custom types
DO $$ BEGIN
    CREATE TYPE user_role AS ENUM ('user', 'admin');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE vote_type AS ENUM ('up', 'down');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE notification_type AS ENUM ('answer', 'comment', 'mention', 'accepted');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Profiles table (extends Supabase auth)
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  display_name text,
  bio text,
  avatar_url text,
  role user_role DEFAULT 'user',
  reputation integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Questions table
CREATE TABLE IF NOT EXISTS questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  author_id uuid NOT NULL,
  views integer DEFAULT 0,
  score integer DEFAULT 0,
  accepted_answer_id uuid,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Tags table
CREATE TABLE IF NOT EXISTS tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  description text,
  color text DEFAULT '#3B82F6',
  usage_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Question tags (many-to-many)
CREATE TABLE IF NOT EXISTS question_tags (
  question_id uuid NOT NULL,
  tag_id uuid NOT NULL,
  PRIMARY KEY (question_id, tag_id)
);

-- Answers table
CREATE TABLE IF NOT EXISTS answers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id uuid NOT NULL,
  author_id uuid NOT NULL,
  content text NOT NULL,
  score integer DEFAULT 0,
  is_accepted boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Votes table
CREATE TABLE IF NOT EXISTS votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  answer_id uuid NOT NULL,
  vote_type vote_type NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, answer_id)
);

-- Notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_id uuid NOT NULL,
  actor_id uuid,
  type notification_type NOT NULL,
  question_id uuid,
  answer_id uuid,
  message text NOT NULL,
  read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Add foreign key constraints
DO $$ BEGIN
    ALTER TABLE questions ADD CONSTRAINT fk_questions_author 
      FOREIGN KEY (author_id) REFERENCES profiles(id) ON DELETE CASCADE;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    ALTER TABLE questions ADD CONSTRAINT fk_accepted_answer 
      FOREIGN KEY (accepted_answer_id) REFERENCES answers(id) ON DELETE SET NULL;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    ALTER TABLE question_tags ADD CONSTRAINT fk_question_tags_question 
      FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    ALTER TABLE question_tags ADD CONSTRAINT fk_question_tags_tag 
      FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    ALTER TABLE answers ADD CONSTRAINT fk_answers_question 
      FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    ALTER TABLE answers ADD CONSTRAINT fk_answers_author 
      FOREIGN KEY (author_id) REFERENCES profiles(id) ON DELETE CASCADE;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    ALTER TABLE votes ADD CONSTRAINT fk_votes_user 
      FOREIGN KEY (user_id) REFERENCES profiles(id) ON DELETE CASCADE;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    ALTER TABLE votes ADD CONSTRAINT fk_votes_answer 
      FOREIGN KEY (answer_id) REFERENCES answers(id) ON DELETE CASCADE;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    ALTER TABLE notifications ADD CONSTRAINT fk_notifications_recipient 
      FOREIGN KEY (recipient_id) REFERENCES profiles(id) ON DELETE CASCADE;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    ALTER TABLE notifications ADD CONSTRAINT fk_notifications_actor 
      FOREIGN KEY (actor_id) REFERENCES profiles(id) ON DELETE CASCADE;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    ALTER TABLE notifications ADD CONSTRAINT fk_notifications_question 
      FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    ALTER TABLE notifications ADD CONSTRAINT fk_notifications_answer 
      FOREIGN KEY (answer_id) REFERENCES answers(id) ON DELETE CASCADE;
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_questions_author ON questions(author_id);
CREATE INDEX IF NOT EXISTS idx_questions_created_at ON questions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_answers_question ON answers(question_id);
CREATE INDEX IF NOT EXISTS idx_answers_author ON answers(author_id);
CREATE INDEX IF NOT EXISTS idx_votes_answer ON votes(answer_id);
CREATE INDEX IF NOT EXISTS idx_votes_user ON votes(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_recipient ON notifications(recipient_id);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(recipient_id, read);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE answers ENABLE ROW LEVEL SECURITY;
ALTER TABLE tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE question_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE votes ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Public profiles are viewable by everyone" ON profiles;
DROP POLICY IF EXISTS "Users can insert their own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON profiles;
DROP POLICY IF EXISTS "Questions are viewable by everyone" ON questions;
DROP POLICY IF EXISTS "Authenticated users can create questions" ON questions;
DROP POLICY IF EXISTS "Users can update their own questions" ON questions;
DROP POLICY IF EXISTS "Users can delete their own questions" ON questions;
DROP POLICY IF EXISTS "Answers are viewable by everyone" ON answers;
DROP POLICY IF EXISTS "Authenticated users can create answers" ON answers;
DROP POLICY IF EXISTS "Users can update their own answers" ON answers;
DROP POLICY IF EXISTS "Question authors can mark answers as accepted" ON answers;
DROP POLICY IF EXISTS "Tags are viewable by everyone" ON tags;
DROP POLICY IF EXISTS "Authenticated users can create tags" ON tags;
DROP POLICY IF EXISTS "Question tags are viewable by everyone" ON question_tags;
DROP POLICY IF EXISTS "Authenticated users can add tags to questions" ON question_tags;
DROP POLICY IF EXISTS "Votes are viewable by everyone" ON votes;
DROP POLICY IF EXISTS "Authenticated users can vote" ON votes;
DROP POLICY IF EXISTS "Users can update their own votes" ON votes;
DROP POLICY IF EXISTS "Users can delete their own votes" ON votes;
DROP POLICY IF EXISTS "Users can view their own notifications" ON notifications;
DROP POLICY IF EXISTS "System can create notifications" ON notifications;
DROP POLICY IF EXISTS "Users can update their own notifications" ON notifications;

-- Profiles policies
CREATE POLICY "Public profiles are viewable by everyone"
  ON profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can insert their own profile"
  ON profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id);

-- Questions policies
CREATE POLICY "Questions are viewable by everyone"
  ON questions FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create questions"
  ON questions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update their own questions"
  ON questions FOR UPDATE
  USING (auth.uid() = author_id);

CREATE POLICY "Users can delete their own questions"
  ON questions FOR DELETE
  USING (auth.uid() = author_id);

-- Answers policies
CREATE POLICY "Answers are viewable by everyone"
  ON answers FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create answers"
  ON answers FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update their own answers"
  ON answers FOR UPDATE
  USING (auth.uid() = author_id);

CREATE POLICY "Question authors can mark answers as accepted"
  ON answers FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM questions 
      WHERE id = answers.question_id AND author_id = auth.uid()
    )
  );

-- Tags policies
CREATE POLICY "Tags are viewable by everyone"
  ON tags FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create tags"
  ON tags FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Question tags policies
CREATE POLICY "Question tags are viewable by everyone"
  ON question_tags FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can add tags to questions"
  ON question_tags FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Votes policies
CREATE POLICY "Votes are viewable by everyone"
  ON votes FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can vote"
  ON votes FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own votes"
  ON votes FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own votes"
  ON votes FOR DELETE
  USING (auth.uid() = user_id);

-- Notifications policies
CREATE POLICY "Users can view their own notifications"
  ON notifications FOR SELECT
  USING (auth.uid() = recipient_id);

CREATE POLICY "System can create notifications"
  ON notifications FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can update their own notifications"
  ON notifications FOR UPDATE
  USING (auth.uid() = recipient_id);

-- Functions and triggers for vote counting
CREATE OR REPLACE FUNCTION update_answer_score()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE answers 
  SET score = (
    SELECT COALESCE(SUM(CASE WHEN vote_type = 'up' THEN 1 ELSE -1 END), 0)
    FROM votes 
    WHERE answer_id = COALESCE(NEW.answer_id, OLD.answer_id)
  )
  WHERE id = COALESCE(NEW.answer_id, OLD.answer_id);
  
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_update_answer_score ON votes;
CREATE TRIGGER trigger_update_answer_score
  AFTER INSERT OR UPDATE OR DELETE ON votes
  FOR EACH ROW
  EXECUTE FUNCTION update_answer_score();

-- Function to update user reputation
CREATE OR REPLACE FUNCTION update_user_reputation()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE profiles 
  SET reputation = (
    SELECT COALESCE(SUM(score), 0)
    FROM answers 
    WHERE author_id = COALESCE(NEW.author_id, OLD.author_id)
  )
  WHERE id = COALESCE(NEW.author_id, OLD.author_id);
  
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_update_user_reputation ON answers;
CREATE TRIGGER trigger_update_user_reputation
  AFTER UPDATE OF score ON answers
  FOR EACH ROW
  EXECUTE FUNCTION update_user_reputation();

-- Insert some default tags
INSERT INTO tags (name, description, color) VALUES 
  ('JavaScript', 'Questions about JavaScript programming language', '#F7DF1E'),
  ('React', 'Questions about React.js library', '#61DAFB'),
  ('TypeScript', 'Questions about TypeScript language', '#3178C6'),
  ('Node.js', 'Questions about Node.js runtime', '#339933'),
  ('CSS', 'Questions about Cascading Style Sheets', '#1572B6'),
  ('HTML', 'Questions about HyperText Markup Language', '#E34F26'),
  ('Python', 'Questions about Python programming language', '#3776AB'),
  ('Database', 'Questions about databases and SQL', '#336791'),
  ('API', 'Questions about Application Programming Interfaces', '#FF6B6B'),
  ('Web Development', 'General web development questions', '#4ECDC4')
ON CONFLICT (name) DO NOTHING;