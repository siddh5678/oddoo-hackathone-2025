import React, { useState, useEffect } from 'react';
import { Header } from './components/layout/Header';
import { AuthModal } from './components/auth/AuthModal';
import { QuestionForm } from './components/questions/QuestionForm';
import { QuestionCard } from './components/questions/QuestionCard';
import { QuestionDetail } from './components/questions/QuestionDetail';
import { AuthProvider } from './contexts/AuthContext';
import { supabase } from './lib/supabase';

interface Question {
  id: string;
  title: string;
  description: string;
  views: number;
  score: number;
  created_at: string;
  updated_at: string;
  accepted_answer_id: string | null;
  author: {
    username: string;
    display_name: string | null;
    reputation: number;
    avatar_url: string | null;
  };
  tags: Array<{
    id: string;
    name: string;
    color: string;
  }>;
  answer_count: number;
}

function AppContent() {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [selectedQuestionId, setSelectedQuestionId] = useState<string | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [showQuestionForm, setShowQuestionForm] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchQuestions();
  }, []);

  const fetchQuestions = async () => {
    try {
      const { data: questionsData, error: questionsError } = await supabase
        .from('questions')
        .select('*')
        .order('created_at', { ascending: false });

      if (questionsError) throw questionsError;

      if (!questionsData || questionsData.length === 0) {
        setQuestions([]);
        return;
      }

      // Get unique author IDs
      const authorIds = [...new Set(questionsData.map(q => q.author_id))];
      
      // Fetch authors separately
      const { data: authorsData, error: authorsError } = await supabase
        .from('profiles')
        .select('*')
        .in('id', authorIds);

      if (authorsError) throw authorsError;

      // Get question IDs for tags and answers
      const questionIds = questionsData.map(q => q.id);

      // Fetch question tags
      const { data: questionTagsData, error: tagsError } = await supabase
        .from('question_tags')
        .select(`
          question_id,
          tag:tags(*)
        `)
        .in('question_id', questionIds);

      if (tagsError) throw tagsError;

      // Fetch answer counts
      const { data: answersData, error: answersError } = await supabase
        .from('answers')
        .select('question_id')
        .in('question_id', questionIds);

      if (answersError) throw answersError;

      // Create lookup maps
      const authorsMap = new Map(authorsData?.map(author => [author.id, author]) || []);
      const tagsMap = new Map();
      const answerCountMap = new Map();

      // Group tags by question
      questionTagsData?.forEach(qt => {
        if (!tagsMap.has(qt.question_id)) {
          tagsMap.set(qt.question_id, []);
        }
        tagsMap.get(qt.question_id).push(qt.tag);
      });

      // Count answers by question
      answersData?.forEach(answer => {
        answerCountMap.set(
          answer.question_id,
          (answerCountMap.get(answer.question_id) || 0) + 1
        );
      });

      // Combine all data
      const formattedQuestions = questionsData.map((question: any) => ({
        ...question,
        author: authorsMap.get(question.author_id) || {
          username: 'Unknown',
          display_name: null,
          reputation: 0,
          avatar_url: null,
        },
        tags: tagsMap.get(question.id) || [],
        answer_count: answerCountMap.get(question.id) || 0,
      }));

      setQuestions(formattedQuestions);
    } catch (error) {
      console.error('Error fetching questions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAuthAction = (action: 'login' | 'register') => {
    setAuthMode(action);
    setShowAuthModal(true);
  };

  const handleNewQuestion = () => {
    setShowQuestionForm(true);
  };

  const handleQuestionCreated = () => {
    fetchQuestions();
  };

  if (selectedQuestionId) {
    return (
      <QuestionDetail
        questionId={selectedQuestionId}
        onBack={() => setSelectedQuestionId(null)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header onNewQuestion={handleNewQuestion} onAuthAction={handleAuthAction} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Welcome to <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">StackIt</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            A collaborative platform for developers to ask questions, share knowledge, and build amazing things together.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg border border-gray-200 p-6 text-center">
            <div className="text-3xl font-bold text-purple-600 mb-2">{questions.length}</div>
            <div className="text-gray-600">Questions</div>
          </div>
          <div className="bg-white rounded-lg border border-gray-200 p-6 text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">
              {questions.reduce((acc, q) => acc + q.answer_count, 0)}
            </div>
            <div className="text-gray-600">Answers</div>
          </div>
          <div className="bg-white rounded-lg border border-gray-200 p-6 text-center">
            <div className="text-3xl font-bold text-orange-600 mb-2">
              {questions.filter(q => q.accepted_answer_id).length}
            </div>
            <div className="text-gray-600">Solved</div>
          </div>
        </div>

        {/* Questions List */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Recent Questions</h2>
            <div className="flex space-x-2">
              <button className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                Newest
              </button>
              <button className="px-4 py-2 text-gray-600 hover:text-gray-900 transition-colors">
                Active
              </button>
              <button className="px-4 py-2 text-gray-600 hover:text-gray-900 transition-colors">
                Unanswered
              </button>
            </div>
          </div>

          {loading ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
              <p className="text-gray-500 mt-4">Loading questions...</p>
            </div>
          ) : questions.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg mb-4">No questions yet</p>
              <p className="text-gray-400">Be the first to ask a question!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {questions.map((question) => (
                <QuestionCard
                  key={question.id}
                  question={question}
                  onClick={() => setSelectedQuestionId(question.id)}
                />
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Modals */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        mode={authMode}
      />

      <QuestionForm
        isOpen={showQuestionForm}
        onClose={() => setShowQuestionForm(false)}
        onQuestionCreated={handleQuestionCreated}
      />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;