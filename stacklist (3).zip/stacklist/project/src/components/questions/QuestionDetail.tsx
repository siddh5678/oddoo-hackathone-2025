import React, { useState, useEffect } from 'react';
import { ArrowLeft, Eye, Calendar, ChevronUp, ChevronDown, Check, MessageCircle } from 'lucide-react';
import { RichTextEditor } from '../ui/RichTextEditor';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';

interface Question {
  id: string;
  title: string;
  description: string;
  views: number;
  score: number;
  created_at: string;
  accepted_answer_id: string | null;
  author: {
    id: string;
    username: string;
    display_name: string | null;
    reputation: number;
    avatar_url: string | null;
  };
  tags: Array<{
    id: string;
    name: string;
    color: string;
  }>;
}

interface Answer {
  id: string;
  content: string;
  score: number;
  is_accepted: boolean;
  created_at: string;
  author: {
    id: string;
    username: string;
    display_name: string | null;
    reputation: number;
    avatar_url: string | null;
  };
  user_vote?: 'up' | 'down' | null;
}

interface QuestionDetailProps {
  questionId: string;
  onBack: () => void;
}

export function QuestionDetail({ questionId, onBack }: QuestionDetailProps) {
  const [question, setQuestion] = useState<Question | null>(null);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [newAnswer, setNewAnswer] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const { user, profile } = useAuth();

  useEffect(() => {
    fetchQuestionDetails();
    incrementViews();
  }, [questionId]);

  const fetchQuestionDetails = async () => {
    try {
      // Fetch question with author and tags
      const { data: questionData, error: questionError } = await supabase
        .from('questions')
        .select(`
          *,
          author:profiles(*),
          tags:question_tags(
            tag:tags(*)
          )
        `)
        .eq('id', questionId)
        .single();

      if (questionError) throw questionError;

      const formattedQuestion = {
        ...questionData,
        author: questionData.author,
        tags: questionData.tags.map((qt: any) => qt.tag),
      };

      setQuestion(formattedQuestion);

      // Fetch answers with authors and user votes
      const { data: answersData, error: answersError } = await supabase
        .from('answers')
        .select(`
          *,
          author:profiles(*),
          votes:votes(vote_type)
        `)
        .eq('question_id', questionId)
        .order('score', { ascending: false });

      if (answersError) throw answersError;

      const formattedAnswers = answersData.map((answer: any) => {
        const userVote = user 
          ? answer.votes.find((v: any) => v.user_id === user.id)?.vote_type || null
          : null;

        return {
          ...answer,
          user_vote: userVote,
        };
      });

      setAnswers(formattedAnswers);
    } catch (error) {
      console.error('Error fetching question details:', error);
    } finally {
      setLoading(false);
    }
  };

  const incrementViews = async () => {
    await supabase
      .from('questions')
      .update({ views: question?.views ? question.views + 1 : 1 })
      .eq('id', questionId);
  };

  const handleVote = async (answerId: string, voteType: 'up' | 'down') => {
    if (!user) return;

    try {
      const currentAnswer = answers.find(a => a.id === answerId);
      const currentVote = currentAnswer?.user_vote;

      if (currentVote === voteType) {
        // Remove vote
        await supabase
          .from('votes')
          .delete()
          .eq('user_id', user.id)
          .eq('answer_id', answerId);
      } else {
        // Add or update vote
        await supabase
          .from('votes')
          .upsert({
            user_id: user.id,
            answer_id: answerId,
            vote_type: voteType,
          });
      }

      // Refresh answers
      await fetchQuestionDetails();
    } catch (error) {
      console.error('Error voting:', error);
    }
  };

  const handleAcceptAnswer = async (answerId: string) => {
    if (!user || !question || question.author.id !== user.id) return;

    try {
      const isCurrentlyAccepted = question.accepted_answer_id === answerId;
      
      await supabase
        .from('questions')
        .update({ 
          accepted_answer_id: isCurrentlyAccepted ? null : answerId 
        })
        .eq('id', questionId);

      await supabase
        .from('answers')
        .update({ is_accepted: !isCurrentlyAccepted })
        .eq('id', answerId);

      if (!isCurrentlyAccepted) {
        // Create notification for answer author
        const answer = answers.find(a => a.id === answerId);
        if (answer && answer.author.id !== user.id) {
          await supabase
            .from('notifications')
            .insert({
              recipient_id: answer.author.id,
              actor_id: user.id,
              type: 'accepted',
              question_id: questionId,
              answer_id: answerId,
              message: `${profile?.display_name || profile?.username} accepted your answer`,
            });
        }
      }

      await fetchQuestionDetails();
    } catch (error) {
      console.error('Error accepting answer:', error);
    }
  };

  const handleSubmitAnswer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newAnswer.trim()) return;

    setSubmitting(true);

    try {
      const { error } = await supabase
        .from('answers')
        .insert({
          question_id: questionId,
          author_id: user.id,
          content: newAnswer,
        });

      if (error) throw error;

      // Create notification for question author
      if (question && question.author.id !== user.id) {
        await supabase
          .from('notifications')
          .insert({
            recipient_id: question.author.id,
            actor_id: user.id,
            type: 'answer',
            question_id: questionId,
            message: `${profile?.display_name || profile?.username} answered your question`,
          });
      }

      setNewAnswer('');
      await fetchQuestionDetails();
    } catch (error) {
      console.error('Error submitting answer:', error);
    } finally {
      setSubmitting(false);
    }
  };

  const timeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (diffInSeconds < 60) return 'just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)}d ago`;
    
    return date.toLocaleDateString();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (!question) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Question not found</p>
        <button
          onClick={onBack}
          className="mt-4 text-purple-600 hover:text-purple-700"
        >
          Go back
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      {/* Back button */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-purple-600 hover:text-purple-700 mb-6"
      >
        <ArrowLeft size={20} />
        Back to questions
      </button>

      {/* Question */}
      <div className="bg-white rounded-lg border border-gray-200 p-6 mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-4">{question.title}</h1>
        
        <div className="flex items-center space-x-4 text-sm text-gray-500 mb-4">
          <div className="flex items-center gap-1">
            <Eye size={16} />
            <span>{question.views} views</span>
          </div>
          <div className="flex items-center gap-1">
            <Calendar size={16} />
            <span>Asked {timeAgo(question.created_at)}</span>
          </div>
        </div>

        <div className="prose max-w-none mb-6" dangerouslySetInnerHTML={{ __html: question.description }} />

        <div className="flex flex-wrap gap-2 mb-6">
          {question.tags.map((tag) => (
            <span
              key={tag.id}
              className="px-3 py-1 text-sm font-medium text-white rounded-full"
              style={{ backgroundColor: tag.color }}
            >
              {tag.name}
            </span>
          ))}
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-gray-200">
          <div className="flex items-center gap-3">
            {question.author.avatar_url ? (
              <img
                src={question.author.avatar_url}
                alt={question.author.display_name || question.author.username}
                className="w-10 h-10 rounded-full"
              />
            ) : (
              <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white font-medium">
                  {(question.author.display_name || question.author.username).charAt(0).toUpperCase()}
                </span>
              </div>
            )}
            <div>
              <p className="font-medium text-gray-900">
                {question.author.display_name || question.author.username}
              </p>
              <p className="text-sm text-gray-500">
                {question.author.reputation} reputation
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Answers */}
      <div className="mb-8">
        <h2 className="text-xl font-bold text-gray-900 mb-4">
          {answers.length} {answers.length === 1 ? 'Answer' : 'Answers'}
        </h2>

        <div className="space-y-6">
          {answers.map((answer) => (
            <div
              key={answer.id}
              className={`bg-white rounded-lg border p-6 ${
                answer.is_accepted ? 'border-green-300 bg-green-50' : 'border-gray-200'
              }`}
            >
              <div className="flex gap-4">
                {/* Vote controls */}
                <div className="flex flex-col items-center space-y-2">
                  <button
                    onClick={() => handleVote(answer.id, 'up')}
                    disabled={!user}
                    className={`p-1 rounded ${
                      answer.user_vote === 'up'
                        ? 'text-green-600 bg-green-100'
                        : 'text-gray-400 hover:text-green-600'
                    } disabled:opacity-50`}
                  >
                    <ChevronUp size={24} />
                  </button>
                  <span className="font-bold text-lg">{answer.score}</span>
                  <button
                    onClick={() => handleVote(answer.id, 'down')}
                    disabled={!user}
                    className={`p-1 rounded ${
                      answer.user_vote === 'down'
                        ? 'text-red-600 bg-red-100'
                        : 'text-gray-400 hover:text-red-600'
                    } disabled:opacity-50`}
                  >
                    <ChevronDown size={24} />
                  </button>
                  {user && question.author.id === user.id && (
                    <button
                      onClick={() => handleAcceptAnswer(answer.id)}
                      className={`p-1 rounded ${
                        answer.is_accepted
                          ? 'text-green-600 bg-green-100'
                          : 'text-gray-400 hover:text-green-600'
                      }`}
                      title="Accept this answer"
                    >
                      <Check size={24} />
                    </button>
                  )}
                </div>

                {/* Answer content */}
                <div className="flex-1">
                  <div className="prose max-w-none mb-4" dangerouslySetInnerHTML={{ __html: answer.content }} />
                  
                  <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <Calendar size={16} />
                      <span>Answered {timeAgo(answer.created_at)}</span>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      {answer.author.avatar_url ? (
                        <img
                          src={answer.author.avatar_url}
                          alt={answer.author.display_name || answer.author.username}
                          className="w-8 h-8 rounded-full"
                        />
                      ) : (
                        <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center">
                          <span className="text-white text-sm font-medium">
                            {(answer.author.display_name || answer.author.username).charAt(0).toUpperCase()}
                          </span>
                        </div>
                      )}
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          {answer.author.display_name || answer.author.username}
                        </p>
                        <p className="text-xs text-gray-500">
                          {answer.author.reputation} rep
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Answer form */}
      {user ? (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Your Answer</h3>
          <form onSubmit={handleSubmitAnswer}>
            <RichTextEditor
              value={newAnswer}
              onChange={setNewAnswer}
              placeholder="Write your answer here..."
              className="mb-4"
            />
            <button
              type="submit"
              disabled={submitting || !newAnswer.trim()}
              className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-6 py-2 rounded-lg hover:from-purple-700 hover:to-blue-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {submitting ? 'Submitting...' : 'Post Your Answer'}
            </button>
          </form>
        </div>
      ) : (
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 text-center">
          <p className="text-gray-600 mb-4">Please sign in to post an answer</p>
        </div>
      )}
    </div>
  );
}