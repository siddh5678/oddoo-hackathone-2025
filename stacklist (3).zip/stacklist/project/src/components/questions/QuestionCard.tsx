import React from 'react';
import { Eye, MessageCircle, Calendar, CheckCircle } from 'lucide-react';

interface Question {
  id: string;
  title: string;
  description: string;
  views: number;
  score: number;
  created_at: string;
  updated_at: string;
  accepted_answer_id: string | null;
  author: {
    username: string;
    display_name: string | null;
    reputation: number;
    avatar_url: string | null;
  };
  tags: Array<{
    id: string;
    name: string;
    color: string;
  }>;
  answer_count: number;
}

interface QuestionCardProps {
  question: Question;
  onClick: () => void;
}

export function QuestionCard({ question, onClick }: QuestionCardProps) {
  const truncateText = (text: string, maxLength: number) => {
    const plainText = text.replace(/<[^>]*>/g, '');
    return plainText.length > maxLength ? plainText.substring(0, maxLength) + '...' : plainText;
  };

  const timeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (diffInSeconds < 60) return 'just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)}d ago`;
    
    return date.toLocaleDateString();
  };

  return (
    <div
      onClick={onClick}
      className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-all duration-200 cursor-pointer hover:border-purple-200"
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2">
            <h3 className="text-lg font-semibold text-gray-900 line-clamp-2 hover:text-purple-600 transition-colors">
              {question.title}
            </h3>
            {question.accepted_answer_id && (
              <CheckCircle className="text-green-500 flex-shrink-0" size={20} />
            )}
          </div>
          
          <p className="text-gray-600 mb-4 line-clamp-3">
            <span dangerouslySetInnerHTML={{ __html: truncateText(question.description, 200) }} />
          </p>

          <div className="flex flex-wrap gap-2 mb-4">
            {question.tags.map((tag) => (
              <span
                key={tag.id}
                className="px-2 py-1 text-xs font-medium text-white rounded-full"
                style={{ backgroundColor: tag.color }}
              >
                {tag.name}
              </span>
            ))}
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 text-sm text-gray-500">
              <div className="flex items-center gap-1">
                <Eye size={16} />
                <span>{question.views}</span>
              </div>
              <div className="flex items-center gap-1">
                <MessageCircle size={16} />
                <span>{question.answer_count}</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar size={16} />
                <span>{timeAgo(question.created_at)}</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">
                  {question.author.display_name || question.author.username}
                </p>
                <p className="text-xs text-gray-500">
                  {question.author.reputation} rep
                </p>
              </div>
              {question.author.avatar_url ? (
                <img
                  src={question.author.avatar_url}
                  alt={question.author.display_name || question.author.username}
                  className="w-8 h-8 rounded-full"
                />
              ) : (
                <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-medium">
                    {(question.author.display_name || question.author.username).charAt(0).toUpperCase()}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}