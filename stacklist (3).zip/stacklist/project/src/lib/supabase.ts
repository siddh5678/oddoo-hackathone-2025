import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL!;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY!;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          username: string;
          display_name: string | null;
          bio: string | null;
          avatar_url: string | null;
          role: 'user' | 'admin';
          reputation: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          username: string;
          display_name?: string | null;
          bio?: string | null;
          avatar_url?: string | null;
          role?: 'user' | 'admin';
          reputation?: number;
        };
        Update: {
          username?: string;
          display_name?: string | null;
          bio?: string | null;
          avatar_url?: string | null;
          role?: 'user' | 'admin';
          reputation?: number;
          updated_at?: string;
        };
      };
      questions: {
        Row: {
          id: string;
          title: string;
          description: string;
          author_id: string;
          views: number;
          score: number;
          accepted_answer_id: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          title: string;
          description: string;
          author_id: string;
          views?: number;
          score?: number;
        };
        Update: {
          title?: string;
          description?: string;
          views?: number;
          score?: number;
          accepted_answer_id?: string | null;
          updated_at?: string;
        };
      };
      answers: {
        Row: {
          id: string;
          question_id: string;
          author_id: string;
          content: string;
          score: number;
          is_accepted: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          question_id: string;
          author_id: string;
          content: string;
          score?: number;
          is_accepted?: boolean;
        };
        Update: {
          content?: string;
          score?: number;
          is_accepted?: boolean;
          updated_at?: string;
        };
      };
      tags: {
        Row: {
          id: string;
          name: string;
          description: string | null;
          color: string;
          usage_count: number;
          created_at: string;
        };
        Insert: {
          name: string;
          description?: string | null;
          color?: string;
          usage_count?: number;
        };
        Update: {
          name?: string;
          description?: string | null;
          color?: string;
          usage_count?: number;
        };
      };
      votes: {
        Row: {
          id: string;
          user_id: string;
          answer_id: string;
          vote_type: 'up' | 'down';
          created_at: string;
        };
        Insert: {
          user_id: string;
          answer_id: string;
          vote_type: 'up' | 'down';
        };
        Update: {
          vote_type?: 'up' | 'down';
        };
      };
      notifications: {
        Row: {
          id: string;
          recipient_id: string;
          actor_id: string | null;
          type: 'answer' | 'comment' | 'mention' | 'accepted';
          question_id: string | null;
          answer_id: string | null;
          message: string;
          read: boolean;
          created_at: string;
        };
        Insert: {
          recipient_id: string;
          actor_id?: string | null;
          type: 'answer' | 'comment' | 'mention' | 'accepted';
          question_id?: string | null;
          answer_id?: string | null;
          message: string;
          read?: boolean;
        };
        Update: {
          read?: boolean;
        };
      };
    };
  };
};